Arduino IoT Cloud historic data

variables:
  - id: c0dd2f50-548f-4f8a-95bc-1619cf49af95
    name: Humedad
    thingName: DHT11
  - id: 3c588378-244a-4bb1-bd6b-92cefc2bb7ce
    name: Temperatura
    thingName: DHT11
from: 2022-09-28T00:00:00Z
to: 2022-09-29T23:59:59Z

Have fun! :)
