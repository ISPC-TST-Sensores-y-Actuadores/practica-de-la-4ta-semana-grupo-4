Arduino IoT Cloud historic data

variables:
  - id: 11e1d3cc-fb52-48eb-a510-133dc4d16128
    name: hum
    thingName: DHT11
  - id: c56ad5fb-8bad-48e3-8c65-5c294dc899d4
    name: temp
    thingName: DHT11
from: 2022-09-28T00:00:00Z
to: 2022-09-29T23:59:59Z

Have fun! :)
